<?php

namespace Straker\EasyTranslationPlatform\Logger;

class Logger extends \Monolog\Logger
{
}