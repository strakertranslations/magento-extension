<?php
namespace Straker\EasyTranslationPlatform\Model;
interface AttributeTranslationInterface 
{

}