<?php
namespace Straker\EasyTranslationPlatform\Model;
interface JobTypeInterface 
{

}