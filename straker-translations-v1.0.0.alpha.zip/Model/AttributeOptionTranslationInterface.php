<?php
namespace Straker\EasyTranslationPlatform\Model;
interface AttributeOptionTranslationInterface 
{

}