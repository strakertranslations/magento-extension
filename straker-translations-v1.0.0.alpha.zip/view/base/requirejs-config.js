//you could define straker javascript in js/other-libraries.js
var config = {
    paths:{
        "straker" : 'Straker_EasyTranslationPlatform/js/other-libraries'
    }
}